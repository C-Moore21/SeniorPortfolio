---

## Chatroom

Chatroom done by Camden Moore and Zach Young

to run, do the following:
```
0. Clone the repository
1. Configure the server.py file to include your preferred host address
2. Execute server.py
3. Execute client.py and follow prompts
```
